# 神奈川県 Stage2 batch06 v2.1 処理報告

## 概要
- 処理PDF数: 15
- page_map行数: 204
- quotes行数: 2
- schools行数: 15
- error_log行数: 196

## OCR評価
- high: 0
- mid: 1
- low: 2
- impossible: 201

## 候補数
- 同一ページ内境界候補数: 0
- 金額引用候補数: 2

## 仕様
- v2.1スキーマで作成
- sato_result / sato_note は全行空欄
- quote_verification_status は全件 OCR 候補として保持
- 時間制限内で取得済みOCRを使用し、未取得ページは原本確認対象として保持
- 原本PDF・既存成果物・GitHub・Drive上の既存ファイルは変更なし
