# 神奈川県 Stage2 batch04 佐藤確認パック v2.1

## 内容
- PDF索引: 15行
- ページ一覧: 206行
- 引用候補: 68行

## 注意
- quote_verification_status は入力の OCR 候補状態を保持しています。
- amount_status は入力の状態を保持しています。
- sato_result / sato_note は全行空欄です。
- このパックは佐藤確認用です。公開引用に使う前に原本PDFで確認してください。

## ファイル
- sato_review_index_batch04_v2_1.csv
- sato_review_pages_batch04_v2_1.csv
- sato_review_quotes_raw_batch04_v2_1.csv
- sato_review_viewer_batch04_v2_1.html
- sato_review_readme_batch04_v2_1.md
